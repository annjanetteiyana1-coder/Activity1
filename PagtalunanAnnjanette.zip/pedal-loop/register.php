<?php
require "config.php";
$errors = [];
$name = $email = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = strtolower(trim($_POST["email"] ?? ""));
    $pass = $_POST["password"] ?? "";
    $confirm = $_POST["confirm"] ?? "";
    $terms = isset($_POST["terms"]);

    if (strlen($name) < 2) $errors["name"] = "Enter your full name.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors["email"] = "Enter a valid email address.";
    if (strlen($pass) < 8 || !preg_match("/[A-Za-z]/", $pass) || !preg_match("/\d/", $pass))
        $errors["password"] = "Use 8+ characters with at least one letter and one number.";
    if ($pass !== $confirm) $errors["confirm"] = "Passwords do not match.";
    if (!$terms) $errors["terms"] = "Accept the Terms of Use to continue.";

    if (!$errors) {
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);
        if ($check->fetch()) {
            $errors["email"] = "An account with this email already exists.";
        } else {
            $ins = $pdo->prepare("INSERT INTO users (full_name, email, password_hash) VALUES (?, ?, ?)");
            $ins->execute([$name, $email, password_hash($pass, PASSWORD_DEFAULT)]);
            header("Location: login.php?registered=1");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pedal Loop – Register</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<section class="brand">
  <div class="logo">Pedal Loop</div>
  <div>
    <h1>Grab a bike. Ride your city.</h1>
    <p>Create an account to unlock bikes at 200+ stations and save your favorite routes.</p>
  </div>
</section>
<main>
  <div class="card">
    <div class="tabs">
      <a href="login.php">Sign in</a>
      <a href="register.php" class="active">Register</a>
    </div>
    <h2>Create your account</h2>
    <p class="sub">It takes less than a minute.</p>
    <form method="post" novalidate>
      <div class="field">
        <label for="name">Full name</label>
        <input type="text" id="name" name="name" value="<?= e($name) ?>" autocomplete="name">
        <div class="err"><?= e($errors["name"] ?? "") ?></div>
      </div>
      <div class="field">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= e($email) ?>" autocomplete="email">
        <div class="err"><?= e($errors["email"] ?? "") ?></div>
      </div>
      <div class="field">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" autocomplete="new-password">
        <div class="hint">At least 8 characters, with a letter and a number.</div>
        <div class="err"><?= e($errors["password"] ?? "") ?></div>
      </div>
      <div class="field">
        <label for="confirm">Confirm password</label>
        <input type="password" id="confirm" name="confirm" autocomplete="new-password">
        <div class="err"><?= e($errors["confirm"] ?? "") ?></div>
      </div>
      <div class="field">
        <label class="check"><input type="checkbox" name="terms"> I agree to the Terms of Use</label>
        <div class="err"><?= e($errors["terms"] ?? "") ?></div>
      </div>
      <button class="submit" type="submit">Create account</button>
    </form>
  </div>
</main>
</body>
</html>
