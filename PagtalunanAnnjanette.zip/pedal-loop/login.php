<?php
require "config.php";
$error = "";
$email = "";

if (isset($_SESSION["user_id"])) { header("Location: dashboard.php"); exit; }

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = strtolower(trim($_POST["email"] ?? ""));
    $pass = $_POST["password"] ?? "";

    if ($email === "" || $pass === "") {
        $error = "Enter your email and password.";
    } else {
        $stmt = $pdo->prepare("SELECT id, full_name, password_hash FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user && password_verify($pass, $user["password_hash"])) {
            session_regenerate_id(true);
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["user_name"] = $user["full_name"];
            header("Location: dashboard.php");
            exit;
        }
        $error = "Email or password is incorrect. Try again or register.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pedal Loop – Sign in</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<section class="brand">
  <div class="logo">Pedal Loop</div>
  <div>
    <h1>Grab a bike. Ride your city.</h1>
    <p>Create an account to unlock bikes at 200+ stations and save your favorite routes.</p>
  </div>
</section>
<main>
  <div class="card">
    <div class="tabs">
      <a href="login.php" class="active">Sign in</a>
      <a href="register.php">Register</a>
    </div>
    <h2>Welcome back</h2>
    <p class="sub">Sign in to continue your ride.</p>
    <?php if (isset($_GET["registered"])): ?>
      <div class="msg ok">Account created. You can sign in now.</div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="msg bad"><?= e($error) ?></div>
    <?php endif; ?>
    <form method="post" novalidate>
      <div class="field">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= e($email) ?>" autocomplete="email">
      </div>
      <div class="field">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" autocomplete="current-password">
      </div>
      <button class="submit" type="submit">Sign in</button>
    </form>
  </div>
</main>
</body>
</html>
