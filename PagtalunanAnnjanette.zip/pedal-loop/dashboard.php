<?php
require "config.php";
if (!isset($_SESSION["user_id"])) { header("Location: login.php"); exit; }

$stmt = $pdo->prepare("SELECT full_name, email, created_at FROM users WHERE id = ?");
$stmt->execute([$_SESSION["user_id"]]);
$user = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pedal Loop – Dashboard</title>
<link rel="stylesheet" href="style.css">
</head>
<body class="single">
<main>
  <div class="card">
    <h2>Hi, <?= e(explode(" ", $user["full_name"])[0]) ?>!</h2>
    <p class="sub">You are signed in to Pedal Loop.</p>
    <p><strong>Name:</strong> <?= e($user["full_name"]) ?></p>
    <p><strong>Email:</strong> <?= e($user["email"]) ?></p>
    <p style="margin-bottom:24px"><strong>Member since:</strong> <?= e(date("M j, Y", strtotime($user["created_at"]))) ?></p>
    <a class="submit" href="logout.php">Sign out</a>
  </div>
</main>
</body>
</html>
