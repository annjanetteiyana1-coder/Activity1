PEDAL LOOP - Sign In & Register (PHP + MySQL)

HOW TO RUN
1. Open XAMPP Control Panel and Start Apache and MySQL.
2. Open http://localhost/phpmyadmin > Import > choose database.sql > Import.
3. Copy ONE of the project folders into C:\xampp\htdocs\
4. Open in browser:
   - http://localhost/pedal-loop-ajax/   (your original design + database)
   - http://localhost/pedal-loop/        (full PHP version with dashboard)

FOLDERS
pedal-loop-ajax/  index.html, api_login.php, api_register.php, config.php, database.sql
pedal-loop/       index.php, login.php, register.php, dashboard.php, logout.php,
                  config.php, style.css, database.sql

DATABASE: pedal_loop > table users (id, full_name, email, password_hash, created_at)
