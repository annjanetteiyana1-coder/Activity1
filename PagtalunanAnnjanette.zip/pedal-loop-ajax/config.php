<?php
// Database connection (XAMPP defaults: user "root", empty password)
$DB_HOST = "localhost";
$DB_NAME = "pedal_loop";
$DB_USER = "root";
$DB_PASS = "";

try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    die("Database connection failed. Check config.php and make sure MySQL is running.");
}

session_start();

function e($s) { return htmlspecialchars($s, ENT_QUOTES, "UTF-8"); }
