<?php
require "config.php";
header("Content-Type: application/json");

$d = json_decode(file_get_contents("php://input"), true) ?? [];
$name = trim($d["name"] ?? "");
$email = strtolower(trim($d["email"] ?? ""));
$pass = $d["password"] ?? "";

if (strlen($name) < 2) { echo json_encode(["ok" => false, "field" => "rg-name", "error" => "Enter your full name."]); exit; }
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { echo json_encode(["ok" => false, "field" => "rg-email", "error" => "Enter a valid email address."]); exit; }
if (strlen($pass) < 8 || !preg_match("/[A-Za-z]/", $pass) || !preg_match("/\d/", $pass)) {
    echo json_encode(["ok" => false, "field" => "rg-pass", "error" => "Use 8+ characters with at least one letter and one number."]); exit;
}

$check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$check->execute([$email]);
if ($check->fetch()) { echo json_encode(["ok" => false, "field" => "rg-email", "error" => "An account with this email already exists."]); exit; }

$ins = $pdo->prepare("INSERT INTO users (full_name, email, password_hash) VALUES (?, ?, ?)");
$ins->execute([$name, $email, password_hash($pass, PASSWORD_DEFAULT)]);
echo json_encode(["ok" => true]);
