<?php
require "config.php";
header("Content-Type: application/json");

$d = json_decode(file_get_contents("php://input"), true) ?? [];
$email = strtolower(trim($d["email"] ?? ""));
$pass = $d["password"] ?? "";

$stmt = $pdo->prepare("SELECT id, full_name, password_hash FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user && password_verify($pass, $user["password_hash"])) {
    session_regenerate_id(true);
    $_SESSION["user_id"] = $user["id"];
    echo json_encode(["ok" => true, "name" => $user["full_name"]]);
} else {
    echo json_encode(["ok" => false, "error" => "Email or password is incorrect. Try again or register."]);
}
